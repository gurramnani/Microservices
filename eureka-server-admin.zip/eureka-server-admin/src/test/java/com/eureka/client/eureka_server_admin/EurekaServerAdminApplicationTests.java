package com.eureka.client.eureka_server_admin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerAdminApplicationTests {

	@Test
	void contextLoads() {
	}

}
