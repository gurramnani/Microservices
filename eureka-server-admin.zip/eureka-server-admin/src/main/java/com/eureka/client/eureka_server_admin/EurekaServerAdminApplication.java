package com.eureka.client.eureka_server_admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaServerAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServerAdminApplication.class, args);
	}

}
