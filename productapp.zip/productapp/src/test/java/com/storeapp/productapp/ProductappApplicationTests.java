package com.storeapp.productapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductappApplicationTests {

	@Test
	void contextLoads() {
	}

}
