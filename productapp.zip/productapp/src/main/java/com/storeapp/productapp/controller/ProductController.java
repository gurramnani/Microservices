package com.storeapp.productapp.controller;


import com.storeapp.productapp.domain.Product;
import com.storeapp.productapp.service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Scope;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@Scope(value = "request")
@RequestMapping("/products")
public class ProductController {

    @Autowired
    @Qualifier(value = "productService")
    private IProductService iProductService;

    @Autowired
    private RestTemplate restTemplate;

    String url = "http://localhost:8085/names";

    @PostMapping(produces = {MediaType.APPLICATION_JSON_VALUE},
            consumes = {MediaType.APPLICATION_JSON_VALUE} )
    @ResponseStatus(code= HttpStatus.CREATED)
    public Product addProduct(@RequestBody Product product){
        return iProductService.addProduct(product);
    }


    @PutMapping(produces = {MediaType.APPLICATION_JSON_VALUE},
            consumes = {MediaType.APPLICATION_JSON_VALUE} )
    @ResponseStatus(code= HttpStatus.OK)
    public Product updateProduct(@RequestBody Product product){
        return iProductService.updateProduct(product);
    }


    @DeleteMapping(value = "/{id}")
    @ResponseStatus(code= HttpStatus.NO_CONTENT)
    public void deleteProductById(@PathVariable("id") Long id) {
        iProductService.deleteProductById(id);
    }


    @GetMapping(value = "/{id}",produces = {MediaType.APPLICATION_JSON_VALUE})
    public Product getProductById(@PathVariable("id") Long id) {
        return iProductService.getProductById(id);
    }


    @GetMapping(value = "/name/{name}",produces = {MediaType.APPLICATION_JSON_VALUE})
    public List<Product> getProductByName(@PathVariable("name") String name) {
        return iProductService.findByName(name);
    }


    @GetMapping(value = "/price/{price}",produces = {MediaType.APPLICATION_JSON_VALUE})
    public List<Product> getProductByPrice(@PathVariable("price") double price) {
        return iProductService.findByPrice(price);
    }


    @GetMapping(produces = {MediaType.APPLICATION_JSON_VALUE})
    public List<Product> getAllProducts() {
        return iProductService.getAllProducts();
    }


    @GetMapping(value = "/brand/{brand}",produces = {MediaType.APPLICATION_JSON_VALUE})
    public List<Product> getProductByBrand(@PathVariable("brand") String brand) {
        return iProductService.findByBrand(brand);
    }

    @GetMapping(value = "/fetchData", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<String>> getStringList(){
        ResponseEntity<List<String>> response = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null, // no request body for GET
                new ParameterizedTypeReference<List<String>>() {}
        );
        return response;
    }
}
