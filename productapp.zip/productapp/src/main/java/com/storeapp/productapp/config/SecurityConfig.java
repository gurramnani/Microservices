package com.storeapp.productapp.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.SecurityFilterChain;
import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        //security filter chain is used configure the security behaviour
        // http security used to configure the security behaviour
       //Used for: Authorization Rules
        http.csrf(AbstractHttpConfigurer::disable).
                authorizeHttpRequests(auth->auth
              //Every request must be authenticated
//                auth.requestMatchers("/h2-console").permitAll()
                        .anyRequest().authenticated()).
                // HERE THE BASIC AUTH IS PROVIDED BY httpBasic
                httpBasic(withDefaults());
        return http.build();
    }

}
