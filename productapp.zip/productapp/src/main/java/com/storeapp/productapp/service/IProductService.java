package com.storeapp.productapp.service;

import com.storeapp.productapp.domain.Product;
import java.util.List;

public interface IProductService {
    public Product addProduct(Product product);
    public Product updateProduct(Product product);
    public List<Product> getAllProducts();
    public Product getProductById(Long id);
    public void deleteProductById(Long id);
    public List<Product> findByName(String name);
    public List<Product> findByPrice(double price);
    public List<Product> findByBrand(String brand);
}
