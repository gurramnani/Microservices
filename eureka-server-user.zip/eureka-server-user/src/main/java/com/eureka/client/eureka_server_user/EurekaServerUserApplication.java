package com.eureka.client.eureka_server_user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaServerUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServerUserApplication.class, args);
	}

}
