package com.eureka.client.eureka_server_user;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
